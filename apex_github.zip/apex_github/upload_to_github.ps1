# ================================================================
#  APEX — GitHub Upload Script
#  Run this ONCE to upload your project to GitHub
#  Requirements: Git installed (winget install Git.Git)
# ================================================================

param(
    [string]$GitHubUsername = "",
    [string]$RepoName       = "apex-youtube-agent",
    [string]$ProjectDir     = "C:\Krish11"
)

$ErrorActionPreference = "Continue"

function Write-Step($n, $msg) { Write-Host ""; Write-Host "  [$n] $msg" -ForegroundColor Cyan }
function Write-OK($msg)   { Write-Host "      OK: $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "      !! $msg" -ForegroundColor Yellow }
function Write-Info($msg) { Write-Host "      $msg" -ForegroundColor DarkGray }

Clear-Host
Write-Host ""
Write-Host "  ================================================" -ForegroundColor Cyan
Write-Host "   APEX — Upload to GitHub" -ForegroundColor Cyan
Write-Host "   Makes your project public + professional" -ForegroundColor Cyan
Write-Host "  ================================================" -ForegroundColor Cyan
Write-Host ""

# ── Step 1: Get GitHub username ───────────────────────────────
Write-Step "1/7" "GitHub setup..."
if (-not $GitHubUsername) {
    Write-Host "  Your GitHub username (e.g. john-doe)" -ForegroundColor White
    Write-Host "  No account? Create free at https://github.com/signup" -ForegroundColor DarkGray
    $GitHubUsername = Read-Host "  GitHub username"
}
if (-not $GitHubUsername) {
    Write-Host "  Username required. Exiting." -ForegroundColor Red; exit 1
}
Write-OK "Username: $GitHubUsername"

# ── Step 2: Check Git installed ───────────────────────────────
Write-Step "2/7" "Checking Git..."
if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Warn "Git not found — installing..."
    winget install Git.Git --silent --accept-package-agreements --accept-source-agreements 2>$null
    $env:PATH += ";C:\Program Files\Git\cmd"
    if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
        Write-Host "  Git install failed. Download from https://git-scm.com" -ForegroundColor Red
        Read-Host "  Install Git then run this script again. Press Enter to exit"
        exit 1
    }
}
Write-OK "Git $(git --version)"

# ── Step 3: Check GitHub CLI or use HTTPS ────────────────────
Write-Step "3/7" "Checking GitHub CLI..."
$hasGH = Get-Command gh -ErrorAction SilentlyContinue
if (-not $hasGH) {
    Write-Info "GitHub CLI not found — trying to install..."
    try {
        winget install GitHub.cli --silent --accept-package-agreements --accept-source-agreements 2>$null
        $env:PATH += ";C:\Program Files\GitHub CLI"
        $hasGH = Get-Command gh -ErrorAction SilentlyContinue
    } catch {}
}
if ($hasGH) { Write-OK "GitHub CLI available — will use for repo creation" }
else        { Write-Warn "GitHub CLI not available — you will create repo manually (step shown below)" }

# ── Step 4: Prepare project ───────────────────────────────────
Write-Step "4/7" "Preparing project files..."
Set-Location $ProjectDir

# Remove sensitive files from any previous state
$sensitiveFiles = @(".apex_config","client_secrets.json","youtube_token.json","apex_data.db")
foreach ($f in $sensitiveFiles) {
    if (Test-Path $f) {
        Write-Warn "Sensitive file found: $f — will be ignored by .gitignore"
    }
}

# Verify .gitignore exists
if (-not (Test-Path ".gitignore")) {
    Write-Info "Creating .gitignore..."
    @"
.apex_config
client_secrets.json
youtube_token.json
*.db
*.sqlite
output/
audio_cache/
art/
clips/
backups/
screenshots/
browser_profile/
manim_scenes/media/
__pycache__/
*.py[cod]
venv/
.env
*.env
"@ | Set-Content ".gitignore" -Encoding UTF8
    Write-OK ".gitignore created"
}

Write-OK "Project ready"

# ── Step 5: Init git repo ─────────────────────────────────────
Write-Step "5/7" "Initialising git repository..."

if (-not (Test-Path ".git")) {
    git init
    Write-OK "Git initialised"
} else {
    Write-OK "Git already initialised"
}

# Set identity if not set
$gitEmail = git config user.email 2>$null
$gitName  = git config user.name  2>$null
if (-not $gitEmail) {
    $email = Read-Host "  Your email for git commits"
    git config user.email $email
}
if (-not $gitName) {
    $name = Read-Host "  Your name for git commits"
    git config user.name $name
}

# Stage everything
git add .
git status --short | Select-Object -First 20 | ForEach-Object { Write-Info $_ }

# Initial commit
$commitMsg = "feat: APEX v1.0 — AI YouTube Content Agent

- 29 Python files, 79 API routes, 17 dashboard pages
- 3-tier animation: slideshow (free) + Manim (free) + Kling/Pika (paid)
- Nova AI persona: memory, voice, desktop control, browser automation
- Full pipeline: script -> images -> voice -> video -> approval -> YouTube
- 20/20 E2E tests passing, all gaps fixed
- One-shot PowerShell installer"

git commit -m $commitMsg
Write-OK "Initial commit created"

# Rename branch to main
git branch -M main
Write-OK "Branch set to: main"

# ── Step 6: Create GitHub repo ────────────────────────────────
Write-Step "6/7" "Creating GitHub repository..."
$repoUrl = "https://github.com/$GitHubUsername/$RepoName"

if ($hasGH) {
    # Try GitHub CLI
    try {
        gh repo create $RepoName `
            --public `
            --description "AI YouTube Content Agent — fully autonomous pipeline from script to upload" `
            --homepage "https://$GitHubUsername.github.io/$RepoName" `
            2>$null
        Write-OK "Repository created: $repoUrl"
    } catch {
        Write-Warn "gh repo create failed — create manually (see below)"
    }
} else {
    Write-Host ""
    Write-Host "  Create your GitHub repo manually:" -ForegroundColor Yellow
    Write-Host "  1. Go to https://github.com/new" -ForegroundColor White
    Write-Host "  2. Repository name: $RepoName" -ForegroundColor White
    Write-Host "  3. Description: AI YouTube Content Agent" -ForegroundColor White
    Write-Host "  4. Visibility: Public" -ForegroundColor White
    Write-Host "  5. DO NOT initialise with README (we have one)" -ForegroundColor Yellow
    Write-Host "  6. Click Create repository" -ForegroundColor White
    Write-Host ""
    Read-Host "  Press Enter once you have created the repository"
}

# ── Step 7: Push to GitHub ────────────────────────────────────
Write-Step "7/7" "Pushing to GitHub..."

git remote remove origin 2>$null
git remote add origin "https://github.com/$GitHubUsername/$RepoName.git"

Write-Host ""
Write-Host "  Pushing... (may ask for GitHub credentials)" -ForegroundColor Yellow
Write-Host "  Use your GitHub username and a Personal Access Token as password" -ForegroundColor DarkGray
Write-Host "  Get token: https://github.com/settings/tokens (repo scope)" -ForegroundColor DarkGray
Write-Host ""

git push -u origin main

if ($LASTEXITCODE -eq 0) {
    Write-Host ""
    Write-Host "  ================================================" -ForegroundColor Green
    Write-Host "   UPLOADED SUCCESSFULLY!" -ForegroundColor Green
    Write-Host "  ================================================" -ForegroundColor Green
    Write-Host ""
    Write-Host "  Repository: $repoUrl" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  NEXT STEPS TO MAKE IT LOOK PROFESSIONAL:" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "  1. Enable GitHub Pages:" -ForegroundColor White
    Write-Host "     $repoUrl/settings/pages" -ForegroundColor DarkGray
    Write-Host "     Source: Deploy from branch -> main -> /docs" -ForegroundColor DarkGray
    Write-Host "     Your landing page: https://$GitHubUsername.github.io/$RepoName" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  2. Add repository topics (helps discovery):" -ForegroundColor White
    Write-Host "     $repoUrl -> About (gear icon) -> Topics:" -ForegroundColor DarkGray
    Write-Host "     youtube-automation, ai-agent, python, flask, deepseek," -ForegroundColor DarkGray
    Write-Host "     content-creation, video-generation, agentic-ai" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  3. Add a social preview image:" -ForegroundColor White
    Write-Host "     Settings -> Social preview -> Upload image (1280x640)" -ForegroundColor DarkGray
    Write-Host ""
    Write-Host "  4. Star your own repo to show it is active" -ForegroundColor White
    Write-Host ""
    Write-Host "  5. Share on:" -ForegroundColor White
    Write-Host "     LinkedIn (show your AI project)" -ForegroundColor DarkGray
    Write-Host "     Twitter/X: 'Built an AI that autonomously runs a YouTube channel'" -ForegroundColor DarkGray
    Write-Host "     Reddit: r/Python, r/MachineLearning, r/youtube" -ForegroundColor DarkGray
    Write-Host "     Hacker News: Show HN" -ForegroundColor DarkGray
    Write-Host ""
    Start-Process $repoUrl
} else {
    Write-Host ""
    Write-Host "  Push failed. Common fixes:" -ForegroundColor Red
    Write-Host "  1. Make sure the GitHub repo exists at: $repoUrl" -ForegroundColor White
    Write-Host "  2. Use Personal Access Token as password (not your GitHub password)" -ForegroundColor White
    Write-Host "     Get token: https://github.com/settings/tokens -> New token -> repo scope" -ForegroundColor DarkGray
    Write-Host "  3. Try: git push -u origin main" -ForegroundColor White
}

Write-Host ""
Read-Host "  Press Enter to exit"
