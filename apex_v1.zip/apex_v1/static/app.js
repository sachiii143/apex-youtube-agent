'use strict';
const $=id=>document.getElementById(id);
const ts=()=>new Date().toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});
const fmtDate=iso=>iso?new Date(iso).toLocaleString('en-GB',{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}):'—';

async function api(url,method='GET',body=null){
  try{const opts={method,headers:{'Content-Type':'application/json'}};if(body)opts.body=JSON.stringify(body);const r=await fetch(url,opts);return await r.json();}
  catch(e){return{error:e.message};}
}
function setTxt(id,val){const el=$(id);if(el)el.textContent=val??'—';}
function autoResize(el){el.style.height='auto';el.style.height=Math.min(el.scrollHeight,120)+'px';}

// ── Navigation ────────────────────────────────────────────────────────────────
function nav(page){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
  const pg=$(`page-${page}`);if(pg)pg.classList.add('active');
  document.querySelectorAll('.nav-item').forEach(n=>{if(n.textContent.trim().toLowerCase().includes(page.split('-')[0].toLowerCase()))n.classList.add('active');});
  const loaders={home:loadHome,pipeline:loadPipeline,approvals:loadApprovals,scripts:loadScripts,
    videos:loadVideos,research:loadBriefs,experiments:loadExperiments,plans:loadPlans,
    audit:loadAudit,globe:initGlobe,settings:loadSettings,analytics:loadAnalytics,
    scheduler:loadScheduler,ads:loadAds,health:loadHealth};
  if(loaders[page])loaders[page]();
}

// ── Log ───────────────────────────────────────────────────────────────────────
function addLog(boxId,msg,type=''){
  const box=$(boxId);if(!box)return;
  const line=document.createElement('div');line.className=`log-line ${type}`;
  line.textContent=`[${ts()}] ${msg}`;box.appendChild(line);box.scrollTop=box.scrollHeight;
  if(box.children.length>200)box.removeChild(box.firstChild);
}
function clearLog(id){const el=$(id);if(el)el.innerHTML='';}

// ── Home ──────────────────────────────────────────────────────────────────────
async function loadHome(){
  const d=await api('/api/pipeline/status');if(d.error)return;
  setTxt('hs-scripts',d.scripts_written??0);setTxt('hs-published',d.videos_published??0);
  setTxt('hs-jobs',(d.jobs?.running??0)+(d.jobs?.pending??0));setTxt('hs-pending',d.approval_cards_pending??0);
  setTxt('ss-scripts',d.scripts_written??0);setTxt('ss-published',d.videos_published??0);
  setTxt('ss-pending',d.approval_cards_pending??0);
  setTxt('ss-images',d.image_usage?.pollinations?.used??0);
  const cnt=d.approval_cards_pending||0;const badge=$('badge-approvals');
  if(badge){badge.textContent=cnt;badge.style.display=cnt>0?'':'none';}
}
async function quickQueue(){
  const topic=$('quickTopic')?.value.trim();if(!topic)return;
  addLog('homeLog',`Queuing: ${topic}`,'info');
  const d=await api('/api/pipeline/queue_episode','POST',{topic});
  if(d.job_id){addLog('homeLog',`Queued → job ${d.job_id.slice(0,8)}`,'ok');if($('quickTopic'))$('quickTopic').value='';}
  else addLog('homeLog',`Failed: ${d.error||'unknown'}`,'err');
}

// ── Pipeline ──────────────────────────────────────────────────────────────────
async function loadPipeline(){
  const d=await api('/api/pipeline/status');if(!d.jobs)return;
  setTxt('kc-pending',d.jobs.pending||0);setTxt('kc-running',d.jobs.running||0);
  setTxt('kc-done',d.jobs.done||0);setTxt('kc-dead',d.jobs.dead||0);
  const img=d.image_usage||{};
  const imgEl=$('imageUsage');
  if(imgEl)imgEl.innerHTML=`<div>Pollinations: ${img.pollinations?.used||0} (unlimited free)</div><div>Ideogram: ${img.ideogram?.used||0}/40 free</div><div>Leonardo: ${img.leonardo?.used||0}/12 free</div>`;
  const sEl=$('pipelineStatus');
  if(sEl)sEl.innerHTML=`<div>Scripts: ${d.scripts_written||0}</div><div>Published: ${d.videos_published||0}</div><div>Awaiting approval: ${d.approval_cards_pending||0}</div>`;
}
async function queueFromPipeline(){
  const topic=$('pipelineTopic')?.value.trim();if(!topic)return;
  const d=await api('/api/pipeline/queue_episode','POST',{topic});
  if(d.job_id){addLog('homeLog',`Queued: ${topic}`,'ok');if($('pipelineTopic'))$('pipelineTopic').value='';loadPipeline();}
}

// ── Approvals ─────────────────────────────────────────────────────────────────
async function loadApprovals(){
  const d=await api('/api/approvals/pending');const list=$('approvalsList');const cards=d.cards||[];
  setTxt('approvalCount',`${cards.length} pending`);if(!list)return;
  if(cards.length===0){list.innerHTML='<div class="note note-ok" style="padding:20px;text-align:center">✅ No pending approvals — all clear</div>';return;}
  list.innerHTML='';
  for(const card of cards){
    const p=card.payload||{};const el=document.createElement('div');el.className='approval-card';
    el.innerHTML=`<div class="approval-card-header"><div class="approval-card-icon">📹</div>
      <div><div style="font-weight:700">${p.title||card.action_type}</div>
      <div style="font-size:10px;color:var(--dim)">Card ${card.card_id.slice(0,12)} · Expires ${fmtDate(card.expires_at)}</div></div>
      <div class="pill pill-pending ml-auto">${card.action_type}</div></div>
      <div class="approval-card-meta">
        <div class="approval-card-row"><span class="approval-card-key">Episode</span><span>${p.episode_id||'—'}</span></div>
        <div class="approval-card-row"><span class="approval-card-key">Title</span><span>${p.title||'—'}</span></div>
        <div class="approval-card-row"><span class="approval-card-key">Visibility</span><span>${p.visibility||'public'}</span></div>
        <div class="approval-card-row"><span class="approval-card-key">Made for kids</span><span>${p.made_for_kids?'Yes':'No'}</span></div>
        <div class="approval-card-row"><span class="approval-card-key">Video</span><span style="font-size:10px">${p.video_path||'—'}</span></div>
        <div class="approval-card-row"><span class="approval-card-key">Tags</span><span style="font-size:10px">${(p.tags||[]).slice(0,6).join(', ')}</span></div>
      </div>
      <div class="approval-actions">
        <button class="btn btn-green" onclick="approveCard('${card.card_id}')">✅ Approve & Upload</button>
        <button class="btn btn-red btn-sm" onclick="rejectCard('${card.card_id}')">✕ Reject</button>
      </div>`;
    list.appendChild(el);
  }
}
async function approveCard(cardId){
  if(!confirm('Approve this card and queue the YouTube upload?'))return;
  const d=await api(`/api/approvals/${cardId}/approve`,'POST',{});
  if(d.ok){addLog('homeLog',`Approved card ${cardId.slice(0,8)} — upload queued`,'ok');loadApprovals();loadHome();}
  else alert('Approval failed: '+(d.reason||d.error));
}
async function rejectCard(cardId){
  const notes=prompt('Reason for rejection?','Not ready');if(notes===null)return;
  const d=await api(`/api/approvals/${cardId}/reject`,'POST',{notes});
  if(d.ok){addLog('homeLog',`Rejected card ${cardId.slice(0,8)}`,'warn');loadApprovals();}
}

// ── Scripts ───────────────────────────────────────────────────────────────────
async function loadScripts(){
  const d=await api('/api/scripts');const list=$('scriptsList');const scripts=d.scripts||[];
  setTxt('scriptCount',`${scripts.length} scripts`);if(!list)return;
  list.innerHTML=scripts.length===0?'<div class="note">No scripts yet. Queue an episode to start.</div>':
    scripts.map(s=>`<div class="card" style="cursor:pointer" onclick="showScript('${s.episode_id}')">
      <div class="flex gap-8" style="align-items:center">
        <div style="flex:1"><div style="font-weight:700">${s.title||s.episode_id}</div>
        <div class="note">${s.episode_id} · ${s.scenes} scenes · ${fmtDate(s.created_at)}</div></div>
        <div class="pill pill-ok">v1</div></div></div>`).join('');
}
async function showScript(episodeId){
  const d=await api(`/api/scripts/${episodeId}`);const el=$('scriptDetail');if(!el)return;
  el.style.display='block';
  el.innerHTML=`<div class="card-header"><div class="card-title">📝 ${d.title}</div></div>
    <div class="flex gap-8" style="margin-bottom:12px;flex-wrap:wrap">
      <div class="pill pill-ok">${d.episode_id}</div><div class="pill pill-standby">${d.scenes?.length||0} scenes</div>
      <div class="pill pill-standby">${d.rights||'Original IP'}</div></div>
    <div class="note" style="margin-bottom:10px">${d.description||''}</div>
    ${(d.scenes||[]).map((s,i)=>`<div style="border:1px solid var(--border);border-radius:6px;padding:10px;margin-bottom:8px">
      <div class="flex gap-8" style="margin-bottom:5px"><div style="font-weight:700;font-size:11px">${s.id}</div>
      <div class="pill pill-standby">${s.comedy_beat||''}</div></div>
      <div class="note" style="margin-bottom:5px">${s.narration||''}</div>
      <div style="font-size:11px;color:var(--teal)">"${s.caption||''}"</div></div>`).join('')}`;
  el.scrollIntoView({behavior:'smooth'});
}

// ── Videos ───────────────────────────────────────────────────────────────────
async function loadVideos(){
  const d=await api('/api/videos');const list=$('videosList');if(!list)return;
  const published=d.published||[];
  list.innerHTML=published.length===0?'<div class="note" style="padding:20px;text-align:center">No videos published yet.</div>':
    published.map(v=>`<div class="card"><div class="flex gap-8" style="align-items:center">
      <div style="flex:1"><div style="font-weight:700">${v.title||v.episode_id}</div>
      <div class="note">${fmtDate(v.published_at)} ${v.dry_run?'· dry-run':''}</div></div>
      ${v.url?`<a href="${v.url}" target="_blank" class="btn btn-sm btn-ghost">▶ Watch</a>`:''}</div></div>`).join('');
}

// ── Research ──────────────────────────────────────────────────────────────────
async function startResearch(){
  const topic=$('researchTopic')?.value.trim();if(!topic)return;
  const ideas=($('researchIdeas')?.value||'').split('\n').map(s=>s.trim()).filter(Boolean);
  setTxt('researchStatus','🔬 Researching... 30-60 seconds');
  const d=await api('/api/research/brief','POST',{topic,ideas});
  if(d.status==='started'){setTxt('researchStatus','✅ Research started — results appear in briefs list');setTimeout(loadBriefs,10000);}
  else setTxt('researchStatus',`Error: ${d.error||'unknown'}`);
}
async function loadBriefs(){
  const d=await api('/api/research/briefs');const list=$('briefsList');if(!list)return;
  const briefs=d.briefs||[];
  list.innerHTML=briefs.length===0?'<div class="note">No research briefs yet.</div>':
    briefs.map(b=>`<div class="card"><div class="flex gap-8" style="align-items:center">
      <div style="flex:1"><div style="font-weight:700">${b.topic}</div>
      <div class="note">${fmtDate(b.created_at)} · ${b.sources} sources · Top: ${b.top_idea||'—'}</div></div>
      <div class="pill pill-ok">brief</div></div></div>`).join('');
}

// ── Experiments ───────────────────────────────────────────────────────────────
async function createExperiment(){
  const name=$('expName')?.value.trim();const hyp=$('expHyp')?.value.trim();const metric=$('expMetric')?.value.trim()||'CTR';
  if(!name||!hyp)return;
  const d=await api('/api/experiments','POST',{name,hypothesis:hyp,metric,
    variants:[{name:'A',description:'Variant A'},{name:'B',description:'Variant B'}],guardrails:['Stop if metric drops below baseline']});
  if(d.exp_id){addLog('homeLog',`Experiment created: ${name}`,'ok');loadExperiments();}
}
async function loadExperiments(){
  const d=await api('/api/experiments');const list=$('experimentsList');if(!list)return;
  const exps=d.experiments||[];
  list.innerHTML=exps.length===0?'<div class="note">No experiments yet.</div>':
    exps.map(e=>`<div class="card"><div class="flex gap-8" style="align-items:center">
      <div style="flex:1"><div style="font-weight:700">${e.name}</div>
      <div class="note">Metric: ${e.metric} · Started ${fmtDate(e.created_at)}</div></div>
      <div class="pill ${e.status==='running'?'pill-working':'pill-ok'}">${e.status}</div>
      ${e.winner?`<div class="pill pill-ok">Winner: ${e.winner}</div>`:''}</div></div>`).join('');
}

// ── Plans ─────────────────────────────────────────────────────────────────────
async function loadPlans(){
  const d=await api('/api/content_plans');const list=$('plansList');if(!list)return;
  const plans=d.plans||[];
  list.innerHTML=plans.length===0?'<div class="note">No content plans yet. Run a research brief to generate one.</div>':
    plans.map(p=>`<div class="card"><div class="flex gap-8" style="align-items:center">
      <div style="flex:1"><div style="font-weight:700">${p.topic}</div>
      <div class="note">${p.status} · ${fmtDate(p.created_at)}</div></div>
      ${p.status==='draft'?`<button class="btn btn-green btn-sm" onclick="approvePlan('${p.plan_id}')">Approve Plan</button>`:''}
      <div class="pill ${p.status==='approved'?'pill-ok':'pill-pending'}">${p.status}</div></div></div>`).join('');
}
async function approvePlan(planId){
  if(!confirm('Approve this content plan? Episodes will be queued for production.'))return;
  const d=await api(`/api/content_plans/${planId}/approve`,'POST',{});
  if(d.ok){loadPlans();loadPipeline();}
}

// ── Analytics ─────────────────────────────────────────────────────────────────
async function loadAnalytics(){
  const s=await api('/api/analytics/channel');
  setTxt('an-videos',s.videos_tracked??'—');setTxt('an-views',s.total_views??'—');
  setTxt('an-ctr',s.avg_ctr_pct!=null?s.avg_ctr_pct+'%':'—');setTxt('an-ret',s.avg_retention_pct!=null?s.avg_retention_pct+'%':'—');
  const videos=await api('/api/analytics/videos');const list=$('analyticsVideosList');if(!list)return;
  const vids=videos.videos||[];
  list.innerHTML=vids.length===0?'<div class="note">No videos tracked yet. Upload a video to start.</div>':
    vids.map(v=>`<div class="card"><div class="flex gap-8" style="align-items:center">
      <div style="flex:1"><div style="font-weight:700">${v.title||v.episode_id}</div>
      <div class="note">${v.youtube_id} · ${fmtDate(v.published_at)}</div></div>
      <button class="btn btn-sm" onclick="fetchVideoAnalytics('${v.youtube_id}')">📊 Stats</button></div></div>`).join('');
}
async function fetchVideoAnalytics(youtubeId){
  const d=await api(`/api/analytics/${youtubeId}`);
  if(d.error){addBubble('nova',`Analytics for ${youtubeId}: ${d.error}`);return;}
  addBubble('nova',`Analytics (${d.period_start}→${d.period_end}):\nViews: ${d.views} · Watch time: ${d.watch_minutes} min\nRetention: ${d.avg_retention_pct}% · CTR: ${d.ctr}%\nLikes: ${d.likes} · Comments: ${d.comments}`);
  nav('chat');
}
async function getEnhancementBrief(){
  const el=$('enhancementBrief');if(el)el.style.display='block';
  const videos=await api('/api/analytics/videos');const ids=(videos.videos||[]).slice(0,5).map(v=>v.youtube_id);
  const brief=await api('/api/enhancement/brief','POST',{youtube_ids:ids});
  if(!el)return;
  const recs=brief.recommendations||[];
  if(recs.length===0){el.innerHTML='<span class="note-warn">Not enough data yet — publish more videos first.</span>';return;}
  el.innerHTML=recs.map(r=>`<div style="border-left:2px solid ${r.priority==='high'?'var(--red)':r.priority==='medium'?'var(--gold)':'var(--green)'};padding:6px 10px;margin-bottom:6px">
    <div style="font-weight:700;font-size:11px">${r.area} <span class="pill ${r.priority==='high'?'pill-dead':r.priority==='medium'?'pill-warn':'pill-ok'}">${r.priority}</span></div>
    <div class="note">${r.recommendation}</div>
    <div style="font-size:10px;color:var(--dim)">${r.evidence} [${r.evidence_type}]</div></div>`).join('')+
    `<div class="note note-warn" style="margin-top:8px">${brief.disclaimer||''}</div>`;
}

// ── Scheduler ─────────────────────────────────────────────────────────────────
async function createSchedule(){
  const name=$('schedName')?.value.trim();const time=$('schedTime')?.value.trim()||'09:00';
  const days=$('schedDays')?.value||'mon,tue,wed,thu,fri,sat,sun';
  const topics=($('schedTopics')?.value||'').split('\n').map(s=>s.trim()).filter(Boolean);
  if(!name||topics.length===0){alert('Enter a schedule name and at least one topic.');return;}
  const d=await api('/api/schedules','POST',{name,time_of_day:time,days_of_week:days,topic_pool:topics,use_enhancement:true});
  if(d.schedule_id){addLog('homeLog',`Schedule created: ${name} — awaiting approval`,'warn');addBubble('nova',`Schedule "${name}" created Boss. It needs your approval before it activates. Check the Scheduler tab.`);loadScheduler();}
}
async function loadScheduler(){
  const d=await api('/api/schedules');const list=$('schedulesList');if(!list)return;
  const scheds=d.schedules||[];
  list.innerHTML=scheds.length===0?'<div class="note">No schedules yet. Create one above.</div>':
    scheds.map(s=>`<div class="card"><div class="flex gap-8" style="align-items:center;margin-bottom:10px">
      <div style="flex:1"><div style="font-weight:700">${s.name}</div>
      <div class="note">${s.time_of_day} · ${s.days_of_week} · ${s.topic_pool.length} topics · Run ${s.run_count}x</div>
      ${s.next_run_at?`<div style="font-size:10px;color:var(--teal)">Next: ${fmtDate(s.next_run_at)}</div>`:''}</div>
      <div class="flex gap-6">
        ${!s.approved?`<button class="btn btn-green btn-sm" onclick="approveSchedule('${s.schedule_id}')">✅ Approve</button>`:''}
        ${s.active?`<button class="btn-ghost btn btn-sm" onclick="pauseSchedule('${s.schedule_id}')">⏸ Pause</button>`:
          `<button class="btn btn-sm" onclick="resumeSchedule('${s.schedule_id}')">▶ Resume</button>`}
        <div class="pill ${s.active?'pill-ok':s.approved?'pill-warn':'pill-pending'}">${s.active?'active':s.approved?'paused':'needs approval'}</div>
      </div></div>
      <div class="note">Topics: ${s.topic_pool.slice(0,3).join(' · ')}${s.topic_pool.length>3?` +${s.topic_pool.length-3} more`:''}</div>
      <div class="note">Enhancement: ${s.use_enhancement?'✓ On (uses analytics to improve each video)':'Off'}</div></div>`).join('');
}
async function approveSchedule(sid){
  if(!confirm('Approve this schedule? APEX will auto-queue videos. You still approve every upload.'))return;
  const d=await api(`/api/schedules/${sid}/approve`,'POST',{});if(d.ok){loadScheduler();loadHome();}
}
async function pauseSchedule(sid){await api(`/api/schedules/${sid}/pause`,'POST',{});loadScheduler();}
async function resumeSchedule(sid){const d=await api(`/api/schedules/${sid}/resume`,'POST',{});if(!d.ok)alert('Cannot resume — not approved yet');loadScheduler();}

// ── Ads ───────────────────────────────────────────────────────────────────────
async function loadAds(){
  const s=await api('/api/ads/summary');
  setTxt('ads-campaigns',s.campaigns??'—');setTxt('ads-spend',s.total_spend_7d!=null?'$'+s.total_spend_7d:'$—');
  setTxt('ads-clicks',s.total_clicks??'—');setTxt('ads-ctr',s.avg_ctr!=null?s.avg_ctr+'%':'—');
  const d=await api('/api/ads/campaigns');const list=$('adsCampaignsList');if(!list)return;
  const camps=d.campaigns||[];
  if(camps.length===0||camps[0]?.error){list.innerHTML=`<div class="note note-warn">${camps[0]?.error||'No campaign data. Connect Google Ads in Settings.'}</div>`;return;}
  list.innerHTML=camps.map(c=>`<div style="border:1px solid var(--border);border-radius:6px;padding:10px">
    <div class="flex gap-8" style="align-items:center"><div style="flex:1"><div style="font-weight:700">${c.name}</div>
    <div class="note">Budget: $${c.budget_daily}/day · Status: ${c.status}</div></div>
    <div class="pill ${c.status==='ENABLED'?'pill-ok':'pill-standby'}">${c.status}</div></div></div>`).join('');
}
async function draftAdsCampaign(){
  const name=$('adsCampName')?.value.trim();const budget=parseFloat($('adsBudget')?.value||'1');
  const videoId=$('adsVideoId')?.value.trim();
  const keywords=($('adsKeywords')?.value||'').split('\n').map(s=>s.trim()).filter(Boolean);
  if(!name||keywords.length===0){alert('Enter campaign name and at least one keyword.');return;}
  const d=await api('/api/ads/draft','POST',{name,budget,video_id:videoId,keywords,ad_text:`Watch ${name} on YouTube`});
  if(d.ok){addLog('homeLog',`Ad campaign drafted: ${name} — needs approval`,'warn');nav('approvals');}
  else alert('Draft failed: '+(d.reason||d.error));
}

// ── Audit ─────────────────────────────────────────────────────────────────────
async function loadAudit(){
  const d=await api('/api/audit?limit=100');const box=$('auditLog');if(!box)return;
  const s=d.summary||{};setTxt('auditSummary',`${s.total_events||0} total events`);box.innerHTML='';
  for(const e of(d.events||[])){
    const line=document.createElement('div');
    const isOk=['VIDEO_UPLOADED','VIDEO_APPROVED','RESEARCH_DONE'].includes(e.action);
    const isErr=['VIDEO_REJECTED','JOB_DEAD_LETTERED'].includes(e.action);
    line.className=`log-line ${isOk?'ok':isErr?'err':'info'}`;
    line.textContent=`[${e.recorded_at?.slice(11,16)}] ${e.action} — ${e.subject||''} ${e.actor!=='system'?`(${e.actor})`:''}`;
    box.appendChild(line);
  }
}

// ── Health ────────────────────────────────────────────────────────────────────
async function loadHealth(){
  const d=await api('/api/health');const el=$('healthChecks');if(!el)return;
  el.innerHTML=`<div class="pill ${d.healthy?'pill-ok':'pill-dead'}" style="margin-bottom:10px">${d.healthy?'✅ Healthy':'⚠️ Issues Found'}</div>`+
    Object.entries(d.checks||{}).map(([key,val])=>`<div class="flex gap-8" style="align-items:flex-start;padding:6px 0;border-bottom:1px solid var(--border)">
      <span style="color:${val.ok?'var(--green)':'var(--red)'};">${val.ok?'✓':'✗'}</span>
      <div style="flex:1"><div style="font-weight:600;font-size:12px">${key.replace(/_/g,' ')}</div>
      ${val.issues?.length?`<div class="note note-err">${val.issues.join(', ')}</div>`:''}
      ${val.available?.length?`<div class="note note-ok">${val.available.join(', ')}</div>`:''}
      ${val.missing?.length?`<div class="note note-warn">Missing: ${val.missing.join(', ')}</div>`:''}
      ${val.error?`<div class="note note-err">${val.error}</div>`:''}</div></div>`).join('');
  await loadBackups();
}
async function createBackup(){
  const label=$('backupLabel')?.value.trim()||'';
  const d=await api('/api/backup','POST',{label});
  if(d.ok){addLog('homeLog',`Backup: ${d.size_kb}KB, ${d.files} files`,'ok');await loadBackups();}
}
async function loadBackups(){
  const d=await api('/api/backups');const list=$('backupsList');if(!list)return;
  const backups=d.backups||[];
  list.innerHTML=backups.length===0?'<div class="note">No backups yet.</div>':
    backups.map(b=>`<div style="border:1px solid var(--border);border-radius:6px;padding:8px 10px;display:flex;align-items:center;gap:10px">
      <div style="flex:1"><div style="font-size:11px;font-weight:600">${b.created_at?.slice(0,16)||'—'} ${b.label?'· '+b.label:''}</div>
      <div class="note">${b.size_kb}KB · ${b.files} files</div></div>
      <button class="btn btn-ghost btn-sm" onclick="restoreBackup('${b.path}')">↩ Restore</button></div>`).join('');
}
async function restoreBackup(path){
  if(!confirm('Restore this backup? Scripts and plans will be overwritten.'))return;
  const d=await api('/api/backup/restore','POST',{path});
  if(d.ok)addLog('homeLog',`Restored ${d.restored_files} files`,'ok');
  else alert('Restore failed: '+d.reason);
}

// ── Settings ──────────────────────────────────────────────────────────────────
function switchSettings(sec){
  document.querySelectorAll('.settings-section').forEach(s=>s.classList.remove('active'));
  document.querySelectorAll('.settings-nav-item').forEach(n=>n.classList.remove('active'));
  const s=$(`sec-${sec}`);if(s)s.classList.add('active');
  document.querySelectorAll('.settings-nav-item').forEach(n=>{if(n.textContent.toLowerCase().includes(sec.split('-')[0]))n.classList.add('active');});
  if(sec==='bible')loadBible();if(sec==='keys')loadKeyStatus();
}
async function loadSettings(){
  const d=await api('/api/settings/status');const sel=$('providerSelect');
  if(sel&&d.LLM_PROVIDER)sel.value=d.LLM_PROVIDER;
  setTxt('providerPill',d.LLM_PROVIDER||'loading');
}
async function loadKeyStatus(){
  const d=await api('/api/settings/status');const list=$('keysList');if(!list||!d)return;
  const keys=[['DEEPSEEK_API_KEY','DeepSeek','platform.deepseek.com — free 500k tokens'],
    ['GEMINI_API_KEY','Gemini','aistudio.google.com — free'],['GROQ_API_KEY','Groq','console.groq.com — free'],
    ['OPENAI_API_KEY','OpenAI','platform.openai.com'],['YOUTUBE_DATA_API_KEY','YouTube Data API','console.cloud.google.com — free'],
    ['TELEGRAM_BOT_TOKEN','Telegram Bot','@BotFather — free'],['BITLY_ACCESS_TOKEN','Bitly','bitly.com — free']];
  list.innerHTML=keys.map(([k,label,hint])=>`<div class="setting-row">
    <div style="flex:1"><div class="setting-label">${label}</div><div class="setting-sub">${hint}</div></div>
    <span class="setting-status ${d[k]==='set'?'set':'unset'}">${d[k]==='set'?'Set':'Not set'}</span>
    <div class="input-row"><input type="password" id="val-${k}" placeholder="Paste key here">
    <button class="btn btn-sm" onclick="saveKey('val-${k}','${k}')">Save</button></div></div>`).join('');
}
async function saveKey(inputId,keyName){
  const val=$(inputId)?.value.trim();if(!val)return;
  await api('/api/settings/save_key','POST',{key:keyName,value:val});
  if($(inputId))$(inputId).value='';loadKeyStatus();loadSettings();
}
async function setProvider(val){await api('/api/settings/save_key','POST',{key:'LLM_PROVIDER',value:val});setTxt('providerPill',val);}
async function loadBible(){
  const d=await api('/api/bible');const el=$('bibleContent');if(!el)return;
  el.innerHTML=`<div class="pill ${d.locked?'pill-warn':'pill-ok'}" style="margin-bottom:10px">${d.locked?'🔒 Locked':'🔓 Unlocked'}</div>`+
    Object.entries(d.characters||{}).map(([name,c])=>`<div style="border:1px solid var(--border);border-radius:6px;padding:12px">
      <div style="font-weight:700;font-size:14px;margin-bottom:6px">${name}</div>
      <div class="flex-col gap-4 note"><div><strong>Role:</strong> ${c.role}</div>
      <div><strong>Catchphrase:</strong> "${c.catchphrase}"</div>
      <div><strong>Copyright:</strong> <span class="note-ok">${c.copyright}</span></div></div></div>`).join('');
}

// ── Chat ──────────────────────────────────────────────────────────────────────
function addBubble(role,content){
  const box=$('chatMessages');if(!box)return;
  const wrap=document.createElement('div');wrap.className=`msg-wrap ${role}`;
  const bub=document.createElement('div');bub.className=`bubble ${role}`;bub.textContent=content;
  const time=document.createElement('div');time.className='msg-ts';time.textContent=ts();
  wrap.append(bub,time);box.appendChild(wrap);box.scrollTop=box.scrollHeight;
  if(role==='nova')speakText(content);
}
function showTyping(){
  const box=$('chatMessages');if(!box)return;
  const w=document.createElement('div');w.id='typing-wrap';w.className='msg-wrap nova';
  w.innerHTML='<div class="bubble nova"><div class="typing-wrap"><div class="tdot"></div><div class="tdot"></div><div class="tdot"></div></div></div>';
  box.appendChild(w);box.scrollTop=box.scrollHeight;
}
function hideTyping(){const t=$('typing-wrap');if(t)t.remove();}

async function sendChatMsg(){
  const ta=$('chatTextarea');const msg=ta?.value.trim();if(!msg)return;
  ta.value='';autoResize(ta);
  addBubble('user',msg);showTyping();ta.disabled=true;
  const d=await api('/api/chat','POST',{message:msg});
  hideTyping();if(d.reply)addBubble('nova',d.reply);ta.disabled=false;ta.focus();
}

async function pollChatUpdates(){
  const d=await api('/api/chat_updates');
  if(d.messages?.length)for(const m of d.messages)addBubble('nova',m.content);
}
setInterval(pollChatUpdates,2500);

// ── Voice output ──────────────────────────────────────────────────────────────
const voice={enabled:true,synth:window.speechSynthesis,voice:null};
(function(){const load=()=>{const voices=voice.synth?.getVoices()||[];const preferred=['Google UK English Female','Microsoft Aria','Samantha'];for(const name of preferred){const v=voices.find(v=>v.name.includes(name));if(v){voice.voice=v;break;}}if(!voice.voice)voice.voice=voices.find(v=>v.lang.startsWith('en'))||voices[0];};load();if(voice.synth)voice.synth.onvoiceschanged=load;})();
function speakText(text){if(!voice.enabled||!voice.synth)return;voice.synth.cancel();const utt=new SpeechSynthesisUtterance(text.replace(/[*_`#]/g,'').slice(0,300));if(voice.voice)utt.voice=voice.voice;utt.rate=1.0;utt.pitch=1.05;voice.synth.speak(utt);}
function toggleVoice(){voice.enabled=!voice.enabled;const btn=$('voiceToggleBtn');if(btn){btn.textContent=voice.enabled?'🔊 Voice':'🔇 Muted';btn.style.color=voice.enabled?'':'var(--red)';}if(!voice.enabled)voice.synth?.cancel();}

// ── Voice input ───────────────────────────────────────────────────────────────
const voiceInput={recognition:null,listening:false};
function initVoiceInput(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return;
  const rec=new SR();rec.continuous=false;rec.interimResults=true;rec.lang='en-US';
  rec.onstart=()=>{voiceInput.listening=true;const b=$('micBtn');if(b){b.textContent='🔴 Listening';b.classList.add('listening');}};
  rec.onresult=e=>{let final='',interim='';for(let i=e.resultIndex;i<e.results.length;i++){const t=e.results[i][0].transcript;if(e.results[i].isFinal)final+=t;else interim+=t;}const ta=$('chatTextarea');if(ta&&interim){ta.value=interim;autoResize(ta);}if(final.trim()){if(ta){ta.value=final.trim();autoResize(ta);}setTimeout(sendChatMsg,150);}};
  rec.onerror=e=>{stopVoiceInput();if(e.error==='not-allowed')addBubble('nova','Allow microphone in browser settings.');};
  rec.onend=stopVoiceInput;voiceInput.recognition=rec;
}
function startVoiceInput(){if(!voiceInput.recognition)initVoiceInput();if(!voiceInput.recognition)return;if(voiceInput.listening){stopVoiceInput();return;}voice.synth?.cancel();try{voiceInput.recognition.start();}catch(e){setTimeout(()=>{try{voiceInput.recognition.start();}catch(e2){}},300);}}
function stopVoiceInput(){voiceInput.listening=false;const b=$('micBtn');if(b){b.textContent='🎤 Speak';b.classList.remove('listening');}try{voiceInput.recognition?.stop();}catch(e){}}

// ── Hands-free wake word ──────────────────────────────────────────────────────
const handsFree={recognition:null,active:false,wakeWords:['hey nova','nova','apex','hey apex']};
function initHandsFree(){
  const SR=window.SpeechRecognition||window.webkitSpeechRecognition;if(!SR)return;
  const rec=new SR();rec.continuous=true;rec.interimResults=true;rec.lang='en-US';
  let wakeDetected=false,commandBuffer='',silenceTimer=null;
  rec.onresult=e=>{let transcript='';for(let i=e.resultIndex;i<e.results.length;i++)transcript+=e.results[i][0].transcript.toLowerCase();
    if(!wakeDetected){if(handsFree.wakeWords.some(w=>transcript.includes(w))){wakeDetected=true;commandBuffer='';let cmd=transcript;for(const w of handsFree.wakeWords)cmd=cmd.replace(w,'').trim();commandBuffer=cmd;setTxt('hfStatus','Nova is listening — speak your command');if(commandBuffer.length>3){clearTimeout(silenceTimer);silenceTimer=setTimeout(()=>sendHandsFreeCommand(commandBuffer),800);}}}
    else{commandBuffer=transcript;for(const w of handsFree.wakeWords)commandBuffer=commandBuffer.replace(w,'').trim();clearTimeout(silenceTimer);silenceTimer=setTimeout(()=>{if(commandBuffer.trim().length>2){sendHandsFreeCommand(commandBuffer.trim());wakeDetected=false;commandBuffer='';setTxt('hfStatus',"Listening for 'Hey Nova'...");}},1500);}};
  rec.onerror=e=>{if(e.error==='no-speech')return;if(e.error==='not-allowed'){setTxt('hfStatus','Mic blocked');handsFree.active=false;return;}if(handsFree.active)setTimeout(()=>{try{rec.start();}catch(e2){}},1000);};
  rec.onend=()=>{if(handsFree.active)setTimeout(()=>{try{rec.start();}catch(e2){}},300);};
  handsFree.recognition=rec;
}
async function toggleHandsFree(){
  if(!handsFree.recognition)initHandsFree();if(!handsFree.recognition){alert('Hands-free requires Chrome or Edge.');return;}
  if(handsFree.active){handsFree.active=false;try{handsFree.recognition.stop();}catch(e){}setTxt('hfStatus','Hands-free off');const btn=$('handsFreeBtn');if(btn){btn.textContent='🎙️ Hands-Free';btn.style.color='';}
  }else{try{await navigator.mediaDevices.getUserMedia({audio:true});handsFree.active=true;handsFree.recognition.start();setTxt('hfStatus',"Listening for 'Hey Nova'...");const btn=$('handsFreeBtn');if(btn){btn.textContent='🔴 Listening';btn.style.color='var(--green)';}
  }catch(e){alert('Microphone access denied. Allow mic in browser settings.');}}
}
async function sendHandsFreeCommand(command){
  if(!command.trim())return;nav('chat');const ta=$('chatTextarea');if(ta){ta.value=command;autoResize(ta);}
  addBubble('user','🎙️ '+command);showTyping();const d=await api('/api/chat','POST',{message:command});hideTyping();if(d.reply)addBubble('nova',d.reply);
}

// ── Camera ────────────────────────────────────────────────────────────────────
let cameraStream=null;
async function toggleCamera(){
  if(cameraStream){cameraStream.getTracks().forEach(t=>t.stop());cameraStream=null;$('cameraStrip').style.display='none';$('cameraBtn').textContent='📷 Camera';return;}
  try{cameraStream=await navigator.mediaDevices.getUserMedia({video:true});$('cameraFeed').srcObject=cameraStream;$('cameraStrip').style.display='block';$('cameraBtn').textContent='📷 Live';}
  catch(e){addBubble('nova','Camera access blocked — allow it in browser settings.');}
}

// ── File upload ───────────────────────────────────────────────────────────────
let uploadedFileData=null;
function handleFileUpload(input){
  const file=input.files[0];if(!file)return;
  const reader=new FileReader();
  reader.onload=e=>{const b64=e.target.result.split(',')[1];uploadedFileData={name:file.name,type:file.type,b64};addBubble('user',`📎 Uploaded: ${file.name}`);};
  reader.readAsDataURL(file);
}

// ── Desktop control ───────────────────────────────────────────────────────────
async function desktopShot(){
  const d=await api('/api/desktop/screenshot','POST',{label:'user_request'});
  if(d.ok&&d.b64){
    nav('chat');const box=$('chatMessages');if(box){
      const wrap=document.createElement('div');wrap.className='msg-wrap nova';
      wrap.innerHTML=`<div class="bubble nova">👁️ Desktop screenshot (${d.width}x${d.height}):<br><img src="data:image/png;base64,${d.b64}" style="max-width:100%;border-radius:8px;margin-top:8px;display:block;border:1px solid var(--border)"></div><div class="msg-ts">${ts()}</div>`;
      box.appendChild(wrap);box.scrollTop=box.scrollHeight;}
    addLog('homeLog',`Screenshot: ${d.width}x${d.height}`,'ok');
  }else addBubble('nova','Screenshot failed: '+(d.error||'install pyautogui: pip install pyautogui'));
}

// ── Multi-client ──────────────────────────────────────────────────────────────
async function switchClient(val){
  if(val==='new'){const name=prompt('Client channel name:');const topic=prompt('Channel topic:');if(!name){$('clientSelector').value='own';return;}
    const d=await api('/api/clients','POST',{name,topic});
    if(d.ok){const opt=document.createElement('option');opt.value=d.client_id;opt.textContent=name;const sel=$('clientSelector');sel.insertBefore(opt,sel.lastElementChild);sel.value=d.client_id;}return;}
  if(val)addBubble('nova',`Switched to channel: ${val}.`);
}

// ── Wizard ────────────────────────────────────────────────────────────────────
async function checkWizard(){
  const d=await api('/api/wizard/status');
  if(d.needs_setup){const overlay=$('wizardOverlay');if(overlay)overlay.style.display='flex';}
  if(d.provider)setTxt('providerPill',d.provider);
}
async function saveWizard(){
  const deepseek=$('wz-deepseek')?.value.trim();const gemini=$('wz-gemini')?.value.trim();const groq=$('wz-groq')?.value.trim();
  if(!deepseek&&!gemini&&!groq){setTxt('wzStatus','⚠️ Add at least one free key — DeepSeek or Gemini');return;}
  setTxt('wzStatus','Saving...');
  const d=await api('/api/wizard/save','POST',{deepseek_key:deepseek,gemini_key:gemini,groq_key:groq,telegram_token:$('wz-telegram')?.value.trim(),bitly_token:$('wz-bitly')?.value.trim()});
  if(d.ok){setTxt('wzStatus',`✅ Saved! Brain: ${d.provider}. Starting APEX...`);setTxt('providerPill',d.provider);setTimeout(()=>{const o=$('wizardOverlay');if(o)o.style.display='none';loadHome();},1200);}
  else setTxt('wzStatus','Error: '+(d.error||'unknown'));
}
function skipWizard(){const o=$('wizardOverlay');if(o)o.style.display='none';addBubble('nova','Running in local mode with Ollama. Add a free DeepSeek or Gemini key in Settings for full capabilities.');}

// ── Neural Globe ──────────────────────────────────────────────────────────────
let globeInit=false;
function initGlobe(){
  if(globeInit)return;globeInit=true;
  const s=document.createElement('script');s.src='https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
  s.onload=buildGlobe;document.head.appendChild(s);
}
function buildGlobe(){
  const canvas=$('novaGlobe');if(!canvas)return;const parent=canvas.parentElement;
  const W=parent.clientWidth||1000,H=parent.clientHeight||600;
  const renderer=new THREE.WebGLRenderer({canvas,antialias:true,alpha:true});
  renderer.setSize(W,H);renderer.setClearColor(0x020810,1);
  const scene=new THREE.Scene();const camera=new THREE.PerspectiveCamera(55,W/H,0.1,1000);camera.position.z=4.5;
  const coreGeo=new THREE.SphereGeometry(0.55,64,64);const coreMat=new THREE.MeshBasicMaterial({color:0x00e5ff,transparent:true,opacity:0.22});scene.add(new THREE.Mesh(coreGeo,coreMat));
  const innerGeo=new THREE.SphereGeometry(0.32,32,32);const innerMat=new THREE.MeshBasicMaterial({color:0xffd700,transparent:true,opacity:0.65});const inner=new THREE.Mesh(innerGeo,innerMat);scene.add(inner);
  const agents=[{label:'APEX',color:0x00e5ff,pos:[2.2,1.1,0.2]},{label:'PULSE',color:0xa855f7,pos:[1.8,-1.3,0.1]},
    {label:'Analytics',color:0x00ff88,pos:[-2.1,0.8,0.3]},{label:'Queue',color:0xffd700,pos:[-1.9,-1.0,0.4]},
    {label:'Memory',color:0x00e5ff,pos:[2.4,-0.2,-0.3]},{label:'Rights',color:0xff4757,pos:[1.2,2.1,0.3]},
    {label:'Audit',color:0xffd700,pos:[-0.4,2.3,0.2]},{label:'Scheduler',color:0x00ff88,pos:[0.3,-2.4,-0.1]}];
  const nodeGeo=new THREE.SphereGeometry(0.10,16,16);const meshes=[];
  agents.forEach(a=>{const m=new THREE.Mesh(nodeGeo,new THREE.MeshBasicMaterial({color:a.color,transparent:true,opacity:0.9}));m.position.set(...a.pos);m._p=Math.random()*Math.PI*2;m._s=0.025+Math.random()*0.02;meshes.push({mesh:m,def:a});scene.add(m);});
  const wires=new THREE.Group();agents.forEach(a=>{const g=new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(0,0,0),new THREE.Vector3(...a.pos)]);wires.add(new THREE.Line(g,new THREE.LineBasicMaterial({color:a.color,transparent:true,opacity:0.35})));});scene.add(wires);
  const pN=280,pPos=new Float32Array(pN*3);for(let i=0;i<pN;i++){const r=1.5+Math.random()*2.8,θ=Math.random()*Math.PI*2,φ=Math.acos(2*Math.random()-1);pPos[i*3]=r*Math.sin(φ)*Math.cos(θ);pPos[i*3+1]=r*Math.sin(φ)*Math.sin(θ);pPos[i*3+2]=r*Math.cos(φ);}
  const pGeo=new THREE.BufferGeometry();pGeo.setAttribute('position',new THREE.BufferAttribute(pPos,3));
  const particles=new THREE.Points(pGeo,new THREE.PointsMaterial({color:0x00e5ff,size:0.025,transparent:true,opacity:0.55}));scene.add(particles);
  const overlay=document.createElement('canvas');overlay.style.cssText='position:absolute;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:5';overlay.width=W;overlay.height=H;parent.appendChild(overlay);
  const ctx=overlay.getContext('2d');const tmp=new THREE.Vector3();let mx=0,my=0,autoY=0;
  parent.addEventListener('mousemove',e=>{mx=(e.clientX/W-0.5);my=(e.clientY/H-0.5);});
  let t=0;
  (function anim(){requestAnimationFrame(anim);t+=0.01;autoY+=0.0018;
    scene.rotation.y=autoY+mx*0.5;scene.rotation.x=my*0.3;
    coreMat.opacity=0.18+Math.sin(t*1.2)*0.06;innerMat.opacity=0.55+Math.sin(t*1.5)*0.15;
    meshes.forEach(({mesh})=>{mesh._p+=mesh._s;mesh.scale.setScalar(0.85+Math.sin(mesh._p)*0.25);mesh.material.opacity=0.6+Math.sin(mesh._p)*0.4;});
    wires.children.forEach((l,i)=>{l.material.opacity=0.2+Math.sin(t*1.3+i)*0.2;});
    particles.rotation.y-=0.0008;renderer.render(scene,camera);
    ctx.clearRect(0,0,W,H);
    meshes.forEach(({mesh,def})=>{tmp.copy(mesh.position).applyMatrix4(scene.matrixWorld);tmp.project(camera);
      const sx=(tmp.x*.5+.5)*W,sy=(-tmp.y*.5+.5)*H;ctx.font='bold 11px -apple-system,sans-serif';
      const tw=ctx.measureText(def.label).width;const bx=sx+16,by=sy-12,bw=tw+20,bh=22;
      ctx.fillStyle='rgba(0,0,0,0.65)';ctx.beginPath();ctx.roundRect(bx,by,bw,bh,8);ctx.fill();
      const rgb=[(def.color>>16)&255,(def.color>>8)&255,def.color&255];
      ctx.fillStyle=`rgb(${rgb})`;ctx.beginPath();ctx.roundRect(bx,by,3,bh,[8,0,0,8]);ctx.fill();
      ctx.fillStyle='#fff';ctx.fillText(def.label,bx+12,by+15);
      ctx.strokeStyle=`rgba(${rgb},.5)`;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(sx,sy);ctx.lineTo(bx,by+11);ctx.stroke();});})();
}

// ── Startup ───────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded',()=>{
  initVoiceInput();initHandsFree();loadHome();
  setTimeout(checkWizard,1500);
  setTimeout(async()=>{
    const h=new Date().getHours();const g=h<12?'Good morning':h<17?'Good afternoon':'Good evening';
    try{const d=await api('/api/briefing');addBubble('nova',`${g} Boss! ${d.text||'All agents standing by. What would you like to do today?'}`);}
    catch(e){addBubble('nova',`${g} Boss — APEX is ready. All agents standing by.`);}
  },900);
  setInterval(loadHome,10000);
  setInterval(loadApprovals,30000);
});

// ═══════════════════════════════════════════════════════════════════════════════
// ANIMATION ENGINE — Tier 1 (slideshow) / Tier 2 (Manim) / Tier 3 (Kling/Pika)
// ═══════════════════════════════════════════════════════════════════════════════

async function loadAnimation() {
  const d = await api('/api/animation/status');

  // Manim pill
  const mp = $('manim-pill');
  if (mp) {
    if (d.manim_available) {
      mp.textContent = '✓ Installed'; mp.className = 'pill pill-ok';
      const rb = $('manim-render-btn'); if (rb) rb.disabled = false;
    } else {
      mp.textContent = 'Not installed'; mp.className = 'pill pill-warn';
    }
  }

  // Kling pill
  const kp = $('kling-pill');
  if (kp) {
    if (d.kling_available) {
      kp.textContent = '✓ ' + d.kling_provider; kp.className = 'pill pill-ok';
      const rb = $('kling-render-btn'); if (rb) rb.disabled = false;
    } else {
      kp.textContent = 'No key set'; kp.className = 'pill pill-warn';
    }
  }

  // Load episode list
  await loadAnimEpisodes();
}

async function loadAnimEpisodes() {
  const d   = await api('/api/scripts');
  const sel = $('animEpisodeSelect');
  if (!sel) return;
  const scripts = d.scripts || [];
  sel.innerHTML = scripts.length === 0
    ? '<option value="">No scripts yet — queue an episode first</option>'
    : scripts.map(s => `<option value="${s.episode_id}">${s.episode_id} — ${s.title}</option>`).join('');
  if (scripts.length > 0) {
    const info = $('anim-episode-info');
    if (info) info.textContent = `${scripts.length} scripts available. Select one to animate.`;
  }
}

async function installManim() {
  addBubble('nova',
    'To install Manim (free, same as 3Blue1Brown):\n\n' +
    'Step 1: Open PowerShell as Administrator\n' +
    'Step 2: Run: pip install manim\n' +
    'Step 3: Windows also needs: winget install MiKTeX.MiKTeX\n' +
    'Step 4: Restart APEX\n\n' +
    'After install, the Manim render button will activate automatically.'
  );
  nav('chat');
}

async function renderManim() {
  const episodeId = $('animEpisodeSelect')?.value;
  if (!episodeId) { alert('Select an episode first.'); return; }
  const statusEl = $('manim-status');
  if (statusEl) { statusEl.textContent = '⏳ Starting Manim render... this takes 2-5 minutes per scene.'; statusEl.style.color = 'var(--teal)'; }
  const d = await api('/api/animation/render_manim', 'POST', { episode_id: episodeId });
  if (d.status === 'started') {
    if (statusEl) statusEl.textContent = '🎬 Rendering in background — Nova will notify you when done. Check the Approvals tab.';
    addLog('homeLog', `Manim render started: ${episodeId}`, 'info');
    addBubble('nova', `Manim animation started for ${episodeId}, Boss. I\'ll render each scene and notify you when the video is ready. This takes about 2-5 minutes per scene.`);
    nav('chat');
  } else {
    if (statusEl) { statusEl.textContent = `Error: ${d.error || d.install || 'unknown'}`; statusEl.style.color = 'var(--red)'; }
    if (d.install) addBubble('nova', `Manim not installed yet, Boss. Run: ${d.install}`);
  }
}

async function renderKling() {
  const episodeId = $('animEpisodeSelect')?.value;
  if (!episodeId) { alert('Select an episode first.'); return; }
  const d = await api('/api/animation/render_kling', 'POST', { episode_id: episodeId });
  if (d.status === 'started') {
    addLog('homeLog', `Animated render started (${d.provider}): ${episodeId}`, 'info');
    addBubble('nova',
      `Animated video generation started for ${episodeId} via ${d.provider}, Boss. ` +
      `Each scene takes about 1-3 minutes. I\'ll notify you when all clips are ready. ` +
      `Check the Approvals tab when done.`
    );
    nav('chat');
  } else {
    addBubble('nova', `Animation failed: ${d.error || 'unknown'}. ${d.howto || ''}`);
    nav('chat');
  }
}

async function saveAnimKey(keyName, inputId) {
  const val = $(inputId)?.value.trim();
  if (!val) { alert('Enter the API key first.'); return; }
  await api('/api/settings/save_key', 'POST', { key: keyName, value: val });
  if ($(inputId)) $(inputId).value = '';
  addBubble('nova', `${keyName} saved, Boss. Click ↻ Check Status to verify.`);
  await loadAnimation();
}

// Wire animation into nav
const _origNavLoaders = window._navLoaders || {};
_origNavLoaders['animation'] = loadAnimation;

// ── Update pipeline to show animation options ─────────────────────────────────
// After a script is done, show render options in the scripts page
const _origShowScript = window.showScript;
window.showScript = async function(episodeId) {
  if (_origShowScript) await _origShowScript(episodeId);
  // Add animation buttons under script detail
  const el = $('scriptDetail');
  if (!el) return;
  const animDiv = document.createElement('div');
  animDiv.style = 'margin-top:12px;display:flex;gap:8px;flex-wrap:wrap';
  animDiv.innerHTML = `
    <div style="width:100%;font-size:11px;color:var(--dim);font-weight:600;margin-bottom:4px">ANIMATE THIS EPISODE:</div>
    <button class="btn btn-sm btn-ghost" onclick="nav('animation');setTimeout(()=>{const s=$('animEpisodeSelect');if(s)s.value='${episodeId}';},300)">
      🎨 Open Animation Studio
    </button>
    <button class="btn btn-sm btn-green" onclick="quickRenderEpisode('${episodeId}')">
      ▶ Quick Render (best available)
    </button>`;
  el.appendChild(animDiv);
};

async function quickRenderEpisode(episodeId) {
  // Auto-pick best available tier
  const status = await api('/api/animation/status');
  addBubble('nova', `Starting best available render for ${episodeId}, Boss...`);
  if (status.kling_available) {
    const d = await api('/api/animation/render_kling', 'POST', { episode_id: episodeId });
    addBubble('nova', d.status === 'started'
      ? `Using ${d.provider} animated render. I\'ll notify you when done.`
      : `Kling failed: ${d.error}. Falling back to slideshow render.`);
  } else if (status.manim_available) {
    const d = await api('/api/animation/render_manim', 'POST', { episode_id: episodeId });
    addBubble('nova', d.status === 'started'
      ? 'Using Manim 2D animation. This takes a few minutes per scene.'
      : `Manim failed: ${d.error}. Falling back to slideshow.`);
  } else {
    // Tier 1 — queue normal pipeline job
    const ep_num = parseInt(episodeId.replace('ep_','')) || 1;
    const script = await api(`/api/scripts/${episodeId}`);
    if (script && script.title) {
      await api('/api/pipeline/queue_publish', 'POST', { card_id: '' });
      addBubble('nova',
        `Using narrated slideshow (always-available tier). ` +
        `To upgrade to animation: install Manim (free) or add a Kling/Pika key. ` +
        `Check the Animation tab for details.`
      );
    }
  }
  nav('chat');
}
